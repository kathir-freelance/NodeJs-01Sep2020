var fs=require('fs');

var data ='hard coding the data';

var ws=fs.createWriteStream('b.txt');

ws.write(data,'UTF-8');
ws.end();
console.log(ws._writableState.ended);
console.log(ws.closed);

ws.on('finish',function(){
	console.log('written');
});

ws.on('end',function(){
	console.log('end is for reading');
});

ws.on('error',function(err){
	console.log(err.stack);
});

console.log('program is done');
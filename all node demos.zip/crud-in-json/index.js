const express = require('express')
const app = express()
const port = 3001;

app.get('/hello', (req, res) => res.send('Hello World!'))
app.get('/', (req, res) => res.send('Home page'))

app.get('/person/:id', (req, res) => {
	

 const personid = persons[req.params.id];
	if(!personid)
	{
	return res.sendStatus(404);
	}
  res.json(personid);

})

app.use(express.json()); //used for converting data into json

app.post('/person', (req, res) => {
  const {id, firstName, lastName, department } = req.body; //destructure
  persons[id] = { id,firstName, lastName, department };
  res.sendStatus(200);
});

app.listen(port, () => console.log(`App listening on port ${port}!`))

//rest api - test - CURL  (linux)
//test rest api of any tech - post chrome plugin 
const persons = {
  '1001': {
    id:1001,
    firstName: 'Steve',
    lastName: 'B',
    department: 'Admin'      
  },
  '1002': {
    id:1002,
    firstName: 'Jane',
    lastName: 'S',
    department: 'Marketing'      
  },
  '1003': {
    id:1003,
    firstName: 'Kathy',
    lastName: 'J',
    department: 'Sales'      
  },
  '1004': {
    id:1004,
    firstName: 'Alex',
    lastName: 'S',
    department: 'Admin'
  }
}



/**
piping : 

get data from one stream and pass it to another stream.

no limit on piping
*/


var fs=require('fs');

var rs=fs.createReadStream('a.txt');

var ws=fs.createWriteStream('c.txt', {'flags':'a','encoding':'utf-8','mode':0666});

rs.pipe(ws);

console.log('prog done');
console.log("server started");
const MongoClient = require('mongodb').MongoClient
const express = require('express');
const app = express();
const bodyParser= require('body-parser')

app.use(bodyParser.urlencoded({ extended: true }))
app.set('view engine', 'ejs')

app.listen(3001, function() {
  console.log('listening on 3001...')
})


app.get('/', function(req, res) {
  res.sendFile(__dirname + '/index.html')
})

app.post('/quotes', (req, res) => {

connectionString='mongodb+srv://kath:kath@cluster0.nkanb.mongodb.net/node-crud?retryWrites=true&w=majority';

MongoClient.connect(connectionString, { useUnifiedTopology: true },(err, client) => {
  if (err){
	 return console.error(err)
	}
  else
  {
	const db = client.db('node-crud')
 	const storeDb = db.collection('mydata')
	storeDb.insertOne(req.body);

	console.log('Connected to Database')
	res.redirect('/')
	}
})

//This will not store in cloud db , untill u whitelist in atlas mongo


})

var dt = require('./mymodule');
console.log(dt);
dt.hello();
dt.home();
console.log(dt.myobj.name+' '+dt.myobj.age)
var fs=require('fs');

var data ='';

var rs=fs.createReadStream('a.txt');
rs.setEncoding('UTF-8');
rs.on('data',function(readData){
	console.log(readData);
});

rs.on('end',function(){
	console.log('data is read ');
});

rs.on('error',function(err){
	console.log(err.stack);
});

console.log('program is done');
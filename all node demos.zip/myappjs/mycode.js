var e=require('mymod');
console.log(e);
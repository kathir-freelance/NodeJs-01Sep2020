
var fs=require('fs');

var zip=require('zlib');

fs.createReadStream('a.txt').pipe(zip.createGzip()).pipe(fs.createWriteStream('myzip.gz'));

console.log('done!!!');

fs.createReadStream('myzip.gz').pipe(zip.createGunzip()).pipe(fs.createWriteStream('result.txt'));

console.log('unzip done!!!');

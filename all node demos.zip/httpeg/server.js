var http=require('http');

var fs=require('fs');

var url=require('url');
http.createServer(function(req,resp){

var path=url.parse(req.url).pathname;
console.log(path);
fs.readFile(path.substr(1),function(err,data){

	if(err)
	{
		console.log(err);
		resp.writeHead(404,{'content-type':'text/html'});
	}
	else{
		resp.writeHead(200,{'content-type':'text/html'});
		resp.write(data.toString());
	}
	resp.end();

});

}).listen(8909);

console.log('server started');
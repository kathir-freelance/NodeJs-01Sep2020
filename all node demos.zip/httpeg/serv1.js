var http = require('http');
var url = require('url');

//create a server object:
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write('<h1>Hello World!</h1>'); //write a response to the client
  //res.write(req.url);
  var q = url.parse(req.url, true).query;
	res.write(q.name+' '+q.city);
  res.end(); //end the response
}).listen(8081); //the server object listens on port 8080



//localhost:8081\?name=aaaa&city=mumbai
var http = require('http');
var url = require('url');

const server=http.createServer((req, res)=>{

	if(req.url==='/')
	{
		res.write('<h1> hi hello '+req.url);
	}
	if(req.url==='/welcome')
	{
		res.write('<h1> welcome'+req.url);
	}
	if(req.url==='/delete')
	{
		res.write('<h1> data deleted !!!'+req.url);
	}

	res.end();
});

server.listen(4000);

console.log('server startd and running in port 4000');

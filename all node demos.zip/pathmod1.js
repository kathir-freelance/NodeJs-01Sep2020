var path=require('path');
var t=path.basename('test/path/file.txt','.txt');
console.log(t);

var t1=path.dirname('test/path/file');
console.log(t1);


exports.myobj={'name':'ajay','age':30};


exports.hello=function(){

console.log('this is a module ');
}

exports.home=()=> console.log('this is arrow function');
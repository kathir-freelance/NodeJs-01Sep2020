var fs=require('fs');
fs.readFile('a.txt', function(err,data){

	if(err)
		return console.log(err);
	console.log(data.toString());	
});

	console.log("read the file");	
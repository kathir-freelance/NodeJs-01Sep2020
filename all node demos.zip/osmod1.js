
var os=require('os');
console.log(os.arch());
console.log(os.freemem());
console.log(os.totalmem());
console.log(os.networkInterfaces());
console.log(os.tmpdir());

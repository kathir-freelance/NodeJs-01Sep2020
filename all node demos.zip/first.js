//import {chalk as chalk} from 'chalk';

const chalk = require('chalk');
const log = console.log;
 
// Combine styled and normal strings
log(chalk.blue('Hello') + ' World' + chalk.red('!'));

log(chalk.blue('Hello world!'));

log(chalk.green(
    'I am a green line ' +
    chalk.blue.underline.bold('with a blue substring') +
    ' that becomes green again!'
));

log(chalk.hex('#DEADED').bold('Bold gray!'));
log(chalk.rgb(123, 45, 67).underline('Underlined reddish color'));
var http = require('http');
var fsobj= require('fs');

console.log('hi' +http); 
console.log('hi' +  JSON.stringify(fsobj)); 

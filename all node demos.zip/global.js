console.log(__dirname); 

console.log(__filename); 

var count=1;

arrFun=()=>{
	console.log('hello number of visit'+(++count));
}
setTimeout(arrFun,2000);
//setInterval(arrFun,2000);

msg='msg to print';
console.log('%s',msg);
//%s - substitution pattern

//%d
//%f
//%i
//%o - JSON.Stringify()

console.log('log level %c  OK','color:green');
console.log('log level %c  PRIORITY','color:blue');
console.log('log level %c  WARN','color:yellow');


//%c - for css code ie fr 2nd arg of the log method


emp=['name','id','salary','age'];
console.table(emp);

nestedobj={
city:{ city:'chn',zip:9877},
name:{fname:'aaa',lname:'nnn'}
}

console.table(nestedobj);


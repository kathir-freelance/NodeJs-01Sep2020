console.log("server started");
const MongoClient = require('mongodb').MongoClient
const express = require('express');
const app = express();
const bodyParser= require('body-parser')

app.use(bodyParser.urlencoded({ extended: true }))
app.get('/', (req, res) => {
  res.sendFile(__dirname+'/index.html');
})
app.get('/home', (req, res) => {
  res.send('Home')
})

//mongo config inside post
app.post('/save', (req, res) => {

connectionString='mongodb+srv://kath:kath@cluster0.nkanb.mongodb.net/node-crud?retryWrites=true&w=majority';

MongoClient.connect(connectionString, { useUnifiedTopology: true },(err, client) => {
  if (err){
	 return console.error(err)
	}
  else
  {
	const db = client.db('node-crud')
 	const storeDb = db.collection('mydata')
	storeDb.insertOne(req.body);
	res.redirect('/')
	console.log('Connected to Database')	

	}
});
});

app.listen(3000, function() {
  console.log('listening on 3000')
})

console.log('server started successfully!!!!');